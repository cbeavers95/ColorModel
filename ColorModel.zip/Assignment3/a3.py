"""
Functions for Assignment A3

This file contains the functions for the assignment. You should replace the stubs
with your own implementations.

Authors: Chelsie Beavers cdb95
Date: October 11, 2019
"""


import introcs
import math


def complement_rgb(rgb):
    """
    Returns the complement of color rgb.

    Parameter rgb: the color to complement
    Precondition: rgb is an RGB object
    """

    # THIS IS WRONG.  FIX IT
    red = 255 - rgb.red
    green = 255 - rgb.green
    blue = 255 - rgb.blue
    #return introcs.RGB(red, green, blue)
    return introcs.RGB(red, green, blue)
    #red = 255-rgb.red
    #green = 255-rgb.green
    #blue = 255-rgb.blue
    #return introcs.RGB(rgb.red, rgb.green, rgb.blue)


def str5(value):
    """
    Returns value as a string, but expanded or rounded to be exactly 5 characters.

    The decimal point counts as one of the five characters.

    Examples:
        str5(1.3546)  is  '1.355'.
        str5(21.9954) is  '22.00'.
        str5(21.994)  is  '21.99'.
        str5(130.59)  is  '130.6'.
        str5(130.54)  is  '130.5'.
        str5(1)       is  '1.000'.

    Parameter value: the number to conver to a 5 character string.
    Precondition: value is a number (int or float), 0 <= value <= 360.
    """

    # DO NOT USE LEN. THINK AS NUMBERS. TURN TO STRING AT END. ADD SAEFTY ZEROES
    # Can add false zeroes and then slice
    # Remember that the rounding takes place at a different place depending
    # on how big value is. Look at the examples in the specification.
    if value >= 0 and value < 10:
        value = float(round(value, 3))
        value = str(value) + '000000'
        return value[:5]
    elif value >= 10 and value < 100:
        value = round(value, 2)
        value = str(value) + '000000'
        return value[:5]
    elif value >=100 and value <= 360:
        value = float(round(value, 1))
        return str(value)
    #1-9
    #10-99.00
    #100-360

    #if len(str(value)) < 5:
        #value = value + ('0' * (5-len(value)))
        #return str(value)
    #elif len(str(value)) > 5:
        #value = float(value)
        #dec_place = (len(str(value))) - 5
        #value = round(value, dec_place)
        #return str(value)
    #elif len(str(value)) == 5:
        #value = flot(value)
        #round(value,)
        #return str(value)
    #pass


def str5_cmyk(cmyk):
    """
    Returns the string representation of cmyk in the form "(C, M, Y, K)".

    In the output, each of C, M, Y, and K should be exactly 5 characters long.
    Hence the output of this function is not the same as str(cmyk)

    Example: if str(cmyk) is

          '(0.0,31.3725490196,31.3725490196,0.0)'

    then str5_cmyk(cmyk) is '(0.000, 31.37, 31.37, 0.000)'. Note the spaces after the
    commas. These must be there.

    Parameter cmyk: the color to convert to a string
    Precondition: cmyk is an CMYK object.
    """

    #cmyk = list(cmyk)
    #cmyk = (float(cmyk))
    #cmyk = str5(cmyk)
    #m = str(str5(cmyk[1]))
    #y = str(str5(cmyk[2]))
    #k = str(str5(cmyk[3]))
    cyan_num = str5(cmyk.cyan)
    magenta_num = str5(cmyk.magenta)
    yellow_num = str5(cmyk.yellow)
    black_num = str5(cmyk.black)
    return '(' + str(cyan_num) + ', ' + str(magenta_num) + ', ' +\
    str(yellow_num) + ', ' + str(black_num) + ')'
    #pass


def str5_hsv(hsv):
    """
    Returns the string representation of hsv in the form "(H, S, V)".

    In the output, each of H, S, and V should be exactly 5 characters long.
    Hence the output of this function is not the same as str(hsv)

    Example: if str(hsv) is

          '(0.0,0.313725490196,1.0)'

    then str5_hsv(hsv) is '(0.000, 0.314, 1.000)'. Note the spaces after the
    commas. These must be there.

    Parameter hsv: the color to convert to a string
    Precondition: hsv is an HSV object.
    """

    hue_num = str5(hsv.hue)
    saturation_num = str5(hsv.saturation)
    value_num = str5(hsv.value)
    return '(' + str(hue_num) + ', ' + str(saturation_num) + ', ' +\
    str(value_num) + ')'
    #pass


def rgb_to_cmyk(rgb):
    """
    Returns a CMYK object equivalent to rgb, with the most black possible.

    Formulae from https://www.rapidtables.com/convert/color/rgb-to-cmyk.html

    Parameter rgb: the color to convert to a CMYK object
    Precondition: rgb is an RGB object
    """

    # The RGB numbers are in the range 0..255.
    # Change them to the range 0..1 by dividing them by 255.0.
    #rgb.red = complement_rgb(rgb.red)//255
    #rgb.green = complement_rgb(rgb.green)//255
#    rgb.blue = complement_rgb(rgb.blue)//255
    #cmyk.cyan = (1 - rgb.red - cmyk.black)//(1 - cmyk.black)
    #cmyk.magenta = (1 - rgb.green - cmyk.black)//(1 - cmyk.black)
    #cmyk.yellow = (1 - rgb.blue - cmyk.black) // (1- cmyk.black)
    #cmyk.black = 1 - max(rgb.red, rgb.green, rgb.blue)
#    return introcs.CMYK(cmyk.cyan, cmyk.magenta, cmyk.yellow, cmyk.black)
    red_color = rgb.red/255
    green_color = rgb.green/255
    blue_color = rgb.blue/255
    black = 1 - max(red_color, green_color, blue_color)
    if black == 1:
        return introcs.CMYK(0, 0, 0, 100.0)
    else:
        cyan = ((1 - red_color - black)/(1 - black)) * 100
        #print(str(cyan) + 'solved')
        #print(str(green_color) + 'before equaton')
        magenta = ((1 - green_color - black)/(1 - black)) *100
        #magenta = magenta * 100
        #print(str(magenta) + 'solved')
        yellow = ((1 - blue_color - black) /(1- black)) * 100
        black = (1 - max(red_color, green_color, blue_color)) *100
        return introcs.CMYK(cyan, magenta, yellow, black)
    #pass


def cmyk_to_rgb(cmyk):
    """
    Returns : color CMYK in space RGB.

    Formulae from en.wikipedia.org/wiki/CMYK_color_model.

    Parameter cmyk: the color to convert to a RGB object
    Precondition: cmyk is an CMYK object.
    """

    # The CMYK numbers are in the range 0.0..100.0.
    # Deal with them the same way as the RGB numbers in rgb_to_cmyk()
    #red_col = round(((1 - cmyk.cyan) * (1 - cmyk.black)// 100), -1)
    #cyan_value = int(cmyk.cyan)//100
    #red_col = (1 - cmyk.cyan) * (1 - cmyk.black)// 100
    #print(str(red_col) + 'testing red color')
    #green_col = (1 - cmyk.magenta) * (1 - cmyk.black)//100
    #print(str(green_col) + "testing green color")
    #blue_col = (1 - cmyk.yellow) * (1 - cmyk.black)//100
    #print(str(blue_col) + 'testing blue color')
    #return introcs.RGB(int(red_col), int(green_col), int(blue_col))
    cyan_value = (cmyk.cyan)/100
    black_value = (cmyk.black)/100
    yellow_value = (cmyk.yellow)/100
    magenta_value = (cmyk.magenta)/100
    red_col = round((1 - cyan_value) * (1 - black_value) * 255)
    #print(str(red_col) + 'testing red color')
    green_col = round((1 - magenta_value) * (1 - black_value) * 255)
    #print(str(green_col) + "testing green color")
    blue_col = round((1 - yellow_value) * (1 - black_value) * 255)
    #print(str(blue_col) + 'testing blue color')
    return introcs.RGB(int(red_col), int(green_col), int(blue_col))
    #pass


def rgb_to_hsv(rgb):
    """
    Return an HSV object equivalent to rgb

    Formulae from https://en.wikipedia.org/wiki/HSL_and_HSV

    Parameter hsv: the color to convert to a HSV object
    Precondition: rgb is an RGB object
    """
    # The RGB numbers are in the range 0..255.
    # h 0-359.999, s 0-1, c 0-1
    # Change them to range 0..1 by dividing them by 255.0.

    # maxx = M = Max, minn = m = min
    maxx = max(rgb.red, rgb.green, rgb.blue)
    minn = min(rgb.red, rgb.green, rgb.blue)
    #print('This is M: ' + str(M))
    #print('This is m: ' + str(m))
    num = maxx/255
    if maxx == minn:
        hue_num = 0
        #return introcs.HSV(0.0, 0.0, num)
        #print('hue_num case 1: ' + str(hue_num))
    elif maxx == (rgb.red or maxx == rgb.green) and (rgb.red >= rgb.blue or\
     rgb.green >= rgb.blue):
        #print('starting case 2')
        hue_num = 60.0 * (rgb.green - rgb.blue)/(maxx - minn)
        #print('hue_num case 2: ' + str(hue_num))
    elif maxx == (rgb.red or maxx == rgb.green) and (rgb.red < rgb.blue or\
     rgb.green <  rgb.blue):
        hue_num = 60.0 * (rgb.green - rgb.blue)/(maxx - minn) + 360.0
        #print('this is red' + str(rgb.red))
    #    print('this is green' + str(rgb.green))
        #print('this is blue' + str(rgb.blue))
        #print('hue_num case 3: ' + str(hue_num))
    elif maxx == rgb.green:
        hue_num = 60.0 * (rgb.blue - rgb.red)/(maxx - minn) + 120.0
        #hue_num = hue_num
        #print('hue_num case 4: ' + str(hue_num))
    elif maxx == rgb.blue:
        hue_num = 60.0 * (rgb.red - rgb.green)/(maxx - minn) + 240.0
        #print('hue_num case 5: ' + str(hue_num))
    if maxx == 0:
        saturation_num = 0
    else:
        m_sat = minn/255
        M_sat = maxx/255
        saturation_num = (1 - m_sat/M_sat)
    value_num = maxx/255
    return introcs.HSV(hue_num, saturation_num, value_num)
    #pass


def hsv_to_rgb(hsv):
    """
    Returns an RGB object equivalent to hsv

    Formulae from https://en.wikipedia.org/wiki/HSL_and_HSV

    Parameter hsv: the color to convert to a RGB object
    Precondition: hsv is an HSV object.
    """

    #value_v = hsv.value
    hi = math.floor(hsv.hue/60)
    #print("this is Hi:" + str(Hi))
    f = (hsv.hue/60 - hi)
    #print("this is f:" + str(f))
    p = (hsv.value * (1-hsv.saturation))
    #print("this is p:" + str(p))
    q = (hsv.value * (1 - (f * hsv.saturation)))
    #print("this is q:" + str(q))
    t = hsv.value * (1-(1-f)*hsv.saturation)
    #print("this is t:" + str(t))
    #red
    if hi == 0 or hi == 5:
        red = round(hsv.value * 255)
        #print(' This is hsv.value: ' + str(hsv.value))
        #print ("this is red1: " + str(red))
    elif hi == 1:
        red = round(q * 255)
        #print ("this is red2: " + str(red))
    elif hi == 2 or hi == 3:
        red = p * 255
        #print ("this is red3: " + str(red))
    elif hi == 4:
        red = round(t * 255)
        #print ("this is red4: " + str(red))
    #green
    if hi == 0:
        green = round(t * 255)
        #print ("this is green1: " + str(green))
    elif hi == 1 or hi == 2:
        green = round(hsv.value * 255)
        #print ("this is green2: " + str(green))
    elif hi == 3:
        green = round(q * 255)
        #print ("this is green3: " + str(green))
    elif hi == 4 or hi == 5:
        green = round(p * 255)
        #print ("this is green4: " + str(green))
    #blue
    if hi == 0 or hi == 1:
        blue = round(p * 255)
        #print ("this is blue1: " + str(blue))
    elif hi == 2:
        blue = round(t * 255)
        #print ("this is blue2: " + str(blue))
    elif hi == 3 or hi == 4:
        blue = round(hsv.value * 255)
        #print ("this is blue3: " + str(blue))
    elif hi == 5:
        blue = round(q * 255)
        #print ("this is blue4: " + str(blue))
    return introcs.RGB(int(red), int(green), int(blue))
    #pass


def contrast_value(value,contrast):
    """
    Returns value adjusted to the "sawtooth curve" for the given contrast

    At contrast = 0, the curve is the normal line y = x, so value is unaffected.
    If contrast < 0, values are pulled closer together, with all values collapsing
    to 0.5 when contrast = -1.  If contrast > 0, values are pulled farther apart,
    with all values becoming 0 or 1 when contrast = 1.

    Parameter value: the value to adjust
    Precondition: value is a float in 0..1

    Parameter contrast: the contrast amount (0 is no contrast)
    Precondition: contrast is a float in -1..1
    """
    x = value
    #print('This is x: ' + str(x))
    c = contrast
    #print('This is c: ' + str(c))
    if x  < (0.25 + (0.25 * c)):
        y = ((1-c)/(1+c))*x
        #print('this is y1: ' + str(y))
    elif x > (0.75 - (0.25 * c)):
        y = ((1-c)/(1+c))  * (x - (3-c)/4) + ((3+c)/4)
        #print('this is y2: ' + str(y))
    else:
        y = ((1+c)/(1-c)) * (x - ((1+c)/4)) + ((1-c)/4)
        #print('this is y3: ' + str(y))
    return (y)
    #pass


def contrast_rgb(rgb,contrast):
    """
    Applies the given contrast to the RGB object rgb

    This function is a PROCEDURE.  It modifies rgb and has no return value.  It should
    apply contrast_value to the red, blue, and green values.

    Parameter rgb: the color to adjust
    Precondition: rgb is an RGB object

    Parameter contrast: the contrast amount (0 is no contrast)
    Precondition: contrast is a float in -1..1
    """

    con_red = (contrast_value(rgb.red/255, contrast)) * 255
    con_green = (contrast_value(rgb.green/255, contrast)) *255
    con_blue = (contrast_value(rgb.blue/255, contrast)) * 255

    rgb.red = int(round(con_red))
    rgb.green = int(round(con_green))
    rgb.blue = int(round(con_blue))
    #introcs.RGB(int(con_red), int(con_green), int(con_blue))
    #pass
